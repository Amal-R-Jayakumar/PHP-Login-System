<?php


define('EMAIL','smartusrs.in@gmail.com');
define('PASSWORD','5$dollars');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'faculty_user');