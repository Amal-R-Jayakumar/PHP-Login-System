import React from 'react'
import { useHistory} from 'react-router-dom'
import { useState, useEffect } from 'react'
import{Link} from 'react-router-dom'
import M from 'materialize-css'

 const CreatePost = ()=>{
    const [title, setTitle] =useState("")
    const [body, setBody] =useState("")
    const [image, setImage] =useState("")
    const [url, setUrl] =useState("")
    const history = useHistory()
    useEffect(()=>{
        if(url){
        fetch("/createpost",{
            method:"post",
            headers:{
                "Content-Type" :"application/json",
                "Authorization":"Bearer " +localStorage.getItem("jwt")
        },
            body:JSON.stringify({
                title,
                body,
                url

            })
        } ).then(res =>res.json())

        .then(data =>{
            if(data.error){
                M.toast({html:data.error, classes:"#c62828 red darken-3"})
                return
            }
            else{
                M.toast({html:"Created Post", classes:"#4caf50 green"})
                history.push('/')
            }
        }).catch(err =>{
            console.log(err)
        })}
    }, [url])

    const postDetails =()=>{
        const data = new FormData()
        data.append("file",image)
        data.append("upload_preset","insta-clone")
        data.append("cloud_name","abhikayila1")
        fetch(" https://api.cloudinary.com/v1_1/abhikayila1/image/upload",{
            method:"post",
            body:data
        }).then(res=>res.json())
        .then(data=>{
            setUrl(data.url)
        })
        .catch(err=>{
            console.log(err)
        })

    }

     return(
         <div className=' card input-field' style={{
                margin:'30px auto',
                maxWidth:'550px',
                padding:'20px',
                textAlign:'center'
        }}>
         <center>
         <h3><span style={{color:"red"}}> Sorry</span> </h3>
<br/>

<h6> This feature is not available for you now. Please contact the service provider</h6>

<br/>
<Link to="/">
<h3><span style={{color:"Green",border:"solid"}}> Go Back </span> </h3>
</Link>
         </center>


         </div>
     )
 }



export default CreatePost
