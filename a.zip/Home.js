import React ,{useState, useEffect , useContext}from 'react'
import {UserContext} from '../../App'
import{Link, useHistory} from 'react-router-dom'
const Home =()=>{

const[data,setData]=useState([])
const {state, dispatch} = useContext(UserContext)

useEffect(()=>{
    fetch("/allposts", {
        headers:{
            Authorization : "Bearer "+ localStorage.getItem('jwt')
        }
    }).then(res=>res.json())
    .then(result=>{

        setData(result.posts)
    })
},[])
const likePost = (id)=>{
    fetch('/like',{
        method:"put",
        headers :{
            "Content-Type":"application/json",
            "Authorization":"Bearer "+localStorage.getItem('jwt')
        },
        body:JSON.stringify({
            postId :id
        })
    }).then(res=>res.json())
    .then(result=>{

        const newData = data.map(item=>{
            if(item._id== result._id){
                return result
            }else{
                return item
            }
        })
        setData(newData)
    }).catch(err =>{
        console.log(err)
    })
 }
const unlikePost = (id)=>{
    fetch('/unlike',{
        method:"put",
        headers :{
            "Content-Type":"application/json",
            "Authorization":"Bearer "+localStorage.getItem('jwt')
        },
        body:JSON.stringify({
            postId :id
        })
    }).then(res=>res.json())
    .then(result=>{

        const newData = data.map(item=>{
            if(item._id== result._id){
                return result
            }else{
                return item
            }
        })
        setData(newData)
    }).catch(err =>{
        console.log(err)
    })
 }

const makeComment =(text, postId)=>{

    fetch("/comment",{
        method :"put",
        headers:{
        "Content-Type" : "application/json",
        "Authorization":"Bearer "+localStorage.getItem('jwt')
    },
    body:JSON.stringify({
        postId,
        text
    })
    }).then(res=>res.json())
    .then(result=>{

        const newData = data.map(item=>{
            if(item._id== result._id){
                return result
            }else{
                return item
            }
        })
        setData(newData)
    }).catch(err =>{
        console.log(err)
    })

}

const deletePost = (postid)=>{
fetch(`/deletepost/:${postid}`,{
    method :"delete",
    headers:{
    "Content-Type" : "application/json",
    "Authorization":"Bearer "+localStorage.getItem('jwt')
}
}).then(res=>res.json())
.then(result=>{

  console.log(result)
  const newData= data.filter(item=>{
    return item._id !== result._id
})
setData(newData)
})
}

return (

  <div class="row " style={{marginLeft:"9%"}}>
  <a href="https://ec2-54-237-96-10.compute-1.amazonaws.com/#/" target="_blank">
    <div class="col s6 ">
            <div className="card home-card1" >
                    <div className="card-image">
                    <img src="https://image.flaticon.com/icons/svg/3048/3048428.svg"/>
                    </div>
                    <div className="card-content">
                    <center><a >Go to class </a></center>
                    </div>
            </div>
            </a>
      </div>


      <div class="col s6 ">
      <Link to="/CreatePost">
              <div className="card home-card1" >
                      <div className="card-image">
                      <img src="https://image.flaticon.com/icons/svg/906/906175.svg" />
                      </div>
                      <div className="card-content">
                      <center><a >Add Class Room</a></center>
                      </div>
              </div>
              </Link>

        </div>


        <div class="col s6 ">
        <Link to="/CreatePost">
                <div className="card home-card1" >
                        <div className="card-image">
                        <img src="https://image.flaticon.com/icons/svg/2883/2883841.svg"/>
                        </div>
                        <div className="card-content">
                         <center><a >Add Teachers</a></center>
                        </div>
                </div>
                </Link>

          </div>

          <div class="col s6 ">
          <Link to="/CreatePost">
                  <div className="card home-card1" >
                          <div className="card-image">
                            <img src="https://image.flaticon.com/icons/svg/3068/3068318.svg"/>
                          </div>
                          <div className="card-content">
                           <center><a >Add Students</a></center>
                          </div>
                  </div>
                  </Link>

            </div>


  </div>

















  )
}

export default Home
