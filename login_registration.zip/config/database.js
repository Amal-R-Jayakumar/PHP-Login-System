module.exports = {
    'connection': {
        'host': '54.237.26.100',
        'user': 'amalrjayakumar',
        'password': '5$Dollars'
    },
    'database': 'amalrjayakumar',
    'user_table': 'users'
}