<?php require_once 'controllers/authcontroller.php'; 
if (isset($_GET['token'])) {
  $token=$_GET['token'];
  verifyUser($token);
}

if (isset($_GET['password_token'])) {
  $password_token=$_GET['password_token'];
  resetPassword($password_token);
}

if (!isset($_SESSION['id'])) {
  header('location: index.php');  
  exit();}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<base href="/">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="icon" type="image/x-icon" href="favicon.ico">
<link href="https://fonts.googleapis.com/css?family=Ubuntu" rel="stylesheet">
<link rel="stylesheet" href="styles.a826808cbbbc50ad2c95.css"></head>
<title>BigMeet</title>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">
  
  BigMeet</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="home.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Hello, <?php echo $_SESSION['name']; ?></a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li>
    </ul>
  </div>
    <form class="form-inline">
    <ul class="navbar-nav">
        <li class="nav-item active"><a class="nav-link" href="bigmeet/home.php?logout=1">Log out</a></li>
        <li class="nav-item"><a class="nav-link" href="#"><?php echo $_SESSION['username']; ?></a></li>
  </ul></form>
</nav>

<div class="container"><div class="row"><div class="col-md-4 offset-md-4 form-div login">
<?php if(isset($_SESSION['message'])): ?>
<div class="alert" <?php echo $_SESSION['alert-class']; ?>>
<?php 
  echo $_SESSION['message']; 
  unset($_SESSION['message']);
  unset($_SESSION['alert-class']);
?>
</div>
<?php endif; ?>







<?php if(!$_SESSION['verified']): ?>
<div calss="alert alert-warning">VERIFY EMAIL. Verification Email sent to 
<strong><?php echo $_SESSION['email']; ?></strong></div>
<?php elseif($_SESSION['verified']===1): ?>
<div calss="alert alert-success"></div>
<?php endif; ?>


</div>
</div>
</div>
<script src="runtime.689ba4fd6cadb82c1ac2.js" defer></script>
<script src="polyfills-es5.04043d3c01917c1850d7.js" nomodule defer></script>
<script src="polyfills.742dcf827e11f0014779.js" defer></script>
<script src="scripts.52f411cb3dcf30f6cbe1.js" defer></script>
<script src="main.70e6fb992125c20dc42a.js" defer></script>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body></html>