
User = bookshelf.Model.extend({
  tableName: 'users'
});


