[![passport banner](http://i.imgur.com/YCkk8t5.png)](https://github.com/tahaway/nodejs-mysql-login-system)

# NodeJs Login System -  MYSQL - Knex - Bookshelf.js

[![Dependencies](https://david-dm.org/jaredhanson/passport.svg)](http://bookshelfjs.org/)

## Install

    $ git clone https://github.com/tahaway/nodejs-mysql-login-system.git .
    $ npm update


## Usage

  Import Mysql Table from SQL/users.sql

## Credits

  - [Taha Ali Adil ](https://www.facebook.com/taha.ali.adil)

